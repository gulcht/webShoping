<?php
    $servername = 'localhost';
    $username = 'adminx2';
    $password = '4ukY5C9z';
    $dbname = 'project';

    $connect = new mysqli($servername, $username, $password, $dbname);
?>